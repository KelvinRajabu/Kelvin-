package com.journaldev.inheritance;
public class Asset extends Company {
    private String asset1;
    private String asset2;
    public Asset(String company_name,String company_id) {
        super(company_name,company_id);
        asset1="AS12";
        asset2="AS34";
    }
    public Asset(String Company_name,String company_id,String asset1) {
        super(company_name,company_id);
        this.asset1=asset1;
    }
    public Asset(String company_name,String company_id,String asset1,String asset2) {
        super(company_name,company_id);
        this.asset1=asset1;
        this.asset2=asset2;
    }
    public void setasset1() {
        this.asset1=asset1;
    }
    public String getasset1() {
        return asset1;
    }
    public void setasset2() {
        this.asset2=asset2;
    }
    public String getasset2() {
        return asset2;
    }
}