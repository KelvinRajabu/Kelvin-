class Apprecition {
    protected double asset_value=3000000.00;
    protected double rate=1500.00;
    protected double new_value=asset+rate;
}
class Add extends Apprecition {
    private String value="value after appreciation is";
    public void method() {
        System.out.println(value);
        System.out.println("balance "+new_value);
    }
}
class Main {
    public static void main(String[] args) {
        Add add=new Add();
        add.method();
    }
}