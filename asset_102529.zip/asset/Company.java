package com.journaldev.inheritance;
public class Company {
    private String company_name;
    private String company_id;
    public Company() {
        company_name="SONS CO.LTD";
        company_id="COMPY456";
    }
    public Company() {
        company_name=company_name;
        company_id=company_id;
    }
    public void setcompanyname() {
        this.company_name=company_name;
    }
    public String getcompanyname() {
        return company_name;
    }
    public void setcompanyid() {
        this.company_id=company_id
    }
    public String getcompanyid() {
        return company_id;
    }
    public String tostring() {
        String y="company name and company id is "+company_name+" and "+company_id;
        return y;
    }
}